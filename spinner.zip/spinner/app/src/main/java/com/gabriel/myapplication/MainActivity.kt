package com.gabriel.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //criando lista de frutas
        val listaTeste = arrayListOf("Gabriel", 16)

        val listaFrutas = arrayListOf<String>()

        listaFrutas.add("Uva")
        listaFrutas.add("Banana")
        listaFrutas.add("Melão")
        listaFrutas.add("Pêra")
        listaFrutas.add("Tomate")

        //criando adaptador

        val frutasAdapter = ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item, listaFrutas)

        spnFrutas.adapter = frutasAdapter

        //belezap
        //belezap
        //belezap
        //belezap
        //belezap






    }
}
